COPY active_learning_queue FROM STDIN WITH CSV HEADER;
id,rule_name,rule_description,classification,confidence,reasons,status,resolved_classification,resolved_notes,created_at,resolved_at

COPY adaptive_weights FROM STDIN WITH CSV HEADER;
signal_type,attack_count,benign_count,last_attack,last_benign,weight,decay_multiplier

COPY anomalies FROM STDIN WITH CSV HEADER;
id,event_id,timestamp,attack_type,severity,src_ip,dst_ip,dst_port,proto,description,detail,alert_sent,discord_sent,created_at

COPY baselines FROM STDIN WITH CSV HEADER;
id,metric,time_window,mean_value,stddev,sample_count,updated_at
1,events_per_minute,2026-06-28 17:30:43.404101+00,1,0,2,2026-06-28 17:30:43.404101+00
2,events_per_minute,2026-06-28 17:50:25.570902+00,1,0,2,2026-06-28 17:50:25.570902+00
3,events_per_minute,2026-06-28 17:50:41.556214+00,1,0,2,2026-06-28 17:50:41.556214+00
4,events_per_minute,2026-06-28 17:51:46.756191+00,1,0,2,2026-06-28 17:51:46.756191+00

COPY drift_events FROM STDIN WITH CSV HEADER;
id,metric,scope,old_mean,new_mean,drift_magnitude,window_size,severity,description,triggered_retrain,timestamp

COPY events FROM STDIN WITH CSV HEADER;
id,timestamp,src_ip,dst_ip,src_hostname,dst_hostname,src_port,dst_port,proto,action,interface,direction,version,ip_ttl,ip_total_length,tcp_flags,tcp_seq,tcp_ack,tcp_window,tcp_options,udp_datalen,icmp_datalen,raw_message,rule_name,log_type,ingested_at
50001,2026-06-28 17:30:00+00,192.168.1.100,10.0.0.1,,,,53,,,,,,,,,,,,,,,"<34>Jun 28 17:30:00 cerberus filter.log: rule ""Antivirus"" passed: proto UDP from 192.168.1.100 to 10.0.0.1 port 53 len 64",,system,2026-06-28 17:30:42.491208+00

COPY ip_threat_profiles FROM STDIN WITH CSV HEADER;
id,ip,unified_score,total_events,firewall_events,http_events,ids_events,zenarmor_events,nginx_events,baseline_deviations,geo_info,first_seen,last_seen

COPY nginx_anomalies FROM STDIN WITH CSV HEADER;
id,timestamp,attack_type,severity,src_ip,path,status_code,description,detail,created_at

COPY nginx_events FROM STDIN WITH CSV HEADER;
id,timestamp,src_ip,method,path,status_code,response_size,user_agent,request_time,interface,ingested_at

COPY rule_baselines FROM STDIN WITH CSV HEADER;
id,rule,rule_name,ip,hour,avg_events_per_hour,std_events_per_hour,max_events_per_hour,min_events_per_hour,protocol_distribution,avg_dst_ports,avg_src_ports,avg_unique_dst_ips,pass_ratio,block_ratio,hourly_distribution,sample_count,avg_port_diversity,avg_dest_diversity,avg_volume,avg_block_ratio,baseline_goodness,baseline_updated,window_start,window_end,last_updated,updated_at

COPY rule_feedback FROM STDIN WITH CSV HEADER;
id,rule_name,timestamp,label,reason,user_id,created_at

COPY schema_versions FROM STDIN WITH CSV HEADER;
version,description,applied_at
1,"Create core tables: events, anomalies, baselines, rule_feedback, indexes",2026-06-27 22:57:50.818704+00
2,Create ip_threat_profiles and active_learning_queue tables,2026-06-27 22:57:50.830522+00
3,Create/upgrade rule_baselines with consolidated schema,2026-06-27 22:57:50.841918+00
4,Create threshold tuning tables,2026-06-27 22:57:50.858657+00
5,Create concept drift events table,2026-06-27 22:57:50.865179+00
6,"Final cleanup: legacy constraints, missing columns, event log_type",2026-06-27 22:57:50.866167+00
7,Create signal_weight_tuning for adaptive threat signal weights,2026-06-27 22:57:50.870949+00
8,Create adaptive_weights table (migrated from threat_engine.py),2026-06-27 22:57:50.874324+00
9,"Performance indexes: log_type + composite timestamp/action for /api/timeline, /api/ids-summary",2026-06-27 22:57:50.877592+00
10,Create nginx_events and nginx_anomalies tables for web traffic monitoring,2026-06-28 03:34:44.226884+00
11,rules-classified covering indexes,2026-06-28 17:09:40.43787+00
12,dashboard composite indexes + ANALYZE,2026-06-28 17:09:40.43787+00
13,Add composite indexes for rules-classified port/dest diversity scans,2026-06-28 17:19:44.454374+00

COPY signal_weight_tuning FROM STDIN WITH CSV HEADER;
signal_type,base_weight,learned_weight,attack_correlations,benign_correlations,total_detections,last_attack_feedback,last_benign_feedback,updated_at

COPY threshold_detection_records FROM STDIN WITH CSV HEADER;
id,anomaly_id,anomaly_type,score,threshold_type,timestamp,created_at

COPY threshold_feedback FROM STDIN WITH CSV HEADER;
id,anomaly_id,label,reason,user_id,created_at
1,1,false_positive,legitimate traffic spike during backup,test,2026-06-28 18:22:36.209453+00
2,1,false_positive,legitimate traffic spike during backup,test,2026-06-28 18:23:38.033699+00
3,1,false_positive,legitimate traffic spike during backup,test,2026-06-28 18:24:13.362268+00
4,1,false_positive,legitimate traffic spike during backup,test,2026-06-28 18:26:37.493956+00
5,1,false_positive,legitimate traffic spike during backup,test,2026-06-28 18:30:53.49585+00
6,1,false_positive,legitimate traffic spike during backup,test,2026-06-28 18:34:20.592363+00
7,1,false_positive,legitimate traffic spike during backup,test,2026-06-28 18:39:27.953218+00
8,1,false_positive,legitimate traffic spike during backup,test,2026-06-28 18:40:13.094265+00
9,1,false_positive,legitimate traffic spike during backup,test,2026-06-28 18:41:49.015089+00
10,1,false_positive,legitimate traffic spike during backup,test,2026-06-28 18:44:22.317981+00
11,1,false_positive,legitimate traffic spike during backup,test,2026-06-28 20:26:35.963617+00
12,1,false_positive,legitimate traffic spike during backup,test,2026-06-28 20:28:05.585957+00
13,1,false_positive,legitimate traffic spike during backup,test,2026-06-28 20:54:23.10143+00
14,1,false_positive,legitimate traffic spike during backup,test,2026-06-28 20:56:01.392373+00
15,1,false_positive,legitimate traffic spike during backup,test,2026-06-28 20:58:06.603947+00
16,1,false_positive,legitimate traffic spike during backup,test,2026-06-28 20:59:41.217123+00
17,1,false_positive,legitimate traffic spike during backup,test,2026-06-28 21:00:21.188067+00
18,1,false_positive,legitimate traffic spike during backup,test,2026-06-28 21:00:30.111876+00
19,1,false_positive,legitimate traffic spike during backup,test,2026-06-28 21:01:37.866497+00
20,1,false_positive,legitimate traffic spike during backup,test,2026-06-28 21:03:29.700682+00
21,1,false_positive,legitimate traffic spike during backup,test,2026-06-28 21:04:58.983998+00
22,1,false_positive,legitimate traffic spike during backup,test,2026-06-28 21:50:10.752985+00
23,1,false_positive,legitimate traffic spike during backup,test,2026-06-29 02:34:14.454292+00
24,1,false_positive,legitimate traffic spike during backup,test,2026-06-29 02:34:49.63423+00
25,1,false_positive,legitimate traffic spike during backup,test,2026-06-29 02:35:23.507023+00
26,1,false_positive,legitimate traffic spike during backup,test,2026-06-29 02:36:00.004064+00
27,1,false_positive,legitimate traffic spike during backup,test,2026-06-29 02:37:30.331531+00
28,1,false_positive,legitimate traffic spike during backup,test,2026-06-29 02:38:13.415894+00
29,1,false_positive,legitimate traffic spike during backup,test,2026-06-29 02:39:14.079815+00
30,1,false_positive,legitimate traffic spike during backup,test,2026-06-29 15:07:20.109414+00
31,1,false_positive,legitimate traffic spike during backup,test,2026-06-29 15:08:34.464197+00
32,1,false_positive,legitimate traffic spike during backup,test,2026-06-30 04:29:45.083256+00
33,1,false_positive,legitimate traffic spike during backup,test,2026-06-30 16:40:40.333718+00
34,1,false_positive,legitimate traffic spike during backup,test,2026-06-30 16:42:02.331534+00
35,1,false_positive,legitimate traffic spike during backup,test,2026-06-30 17:23:18.909695+00
36,1,false_positive,legitimate traffic spike during backup,test,2026-06-30 17:44:49.958429+00
37,1,false_positive,legitimate traffic spike during backup,test,2026-06-30 17:45:14.276699+00

COPY threshold_tuning_history FROM STDIN WITH CSV HEADER;
id,threshold_type,old_value,new_value,reason,created_at

