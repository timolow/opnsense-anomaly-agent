COPY active_learning_queue FROM STDIN WITH CSV HEADER;
id,rule_name,rule_description,classification,confidence,reasons,status,resolved_classification,resolved_notes,created_at,resolved_at

COPY anomalies FROM STDIN WITH CSV HEADER;
id,event_id,timestamp,attack_type,severity,src_ip,dst_ip,dst_port,proto,description,detail,alert_sent,discord_sent,created_at

COPY baselines FROM STDIN WITH CSV HEADER;
id,metric,time_window,mean_value,stddev,sample_count,updated_at

COPY drift_events FROM STDIN WITH CSV HEADER;
id,metric,scope,old_mean,new_mean,drift_magnitude,window_size,severity,description,triggered_retrain,timestamp,created_at

COPY events FROM STDIN WITH CSV HEADER;
id,timestamp,src_ip,dst_ip,src_hostname,dst_hostname,src_port,dst_port,proto,action,interface,direction,version,ip_ttl,ip_total_length,tcp_flags,tcp_seq,tcp_ack,tcp_window,tcp_options,udp_datalen,icmp_datalen,raw_message,rule_name,ingested_at,log_type

COPY ip_threat_profiles FROM STDIN WITH CSV HEADER;
id,ip,unified_score,total_events,firewall_events,http_events,ids_events,zenarmor_events,nginx_events,baseline_deviations,geo_info,first_seen,last_seen

COPY rule_baselines FROM STDIN WITH CSV HEADER;
id,rule,rule_name,ip,hour,avg_events_per_hour,std_events_per_hour,max_events_per_hour,min_events_per_hour,protocol_distribution,avg_dst_ports,avg_src_ports,avg_unique_dst_ips,pass_ratio,block_ratio,hourly_distribution,sample_count,avg_port_diversity,avg_dest_diversity,avg_volume,avg_block_ratio,baseline_goodness,baseline_updated,window_start,window_end,last_updated,updated_at

COPY rule_feedback FROM STDIN WITH CSV HEADER;
id,rule_name,timestamp,label,reason,user_id,created_at
1,test-rule,2026-06-24 14:41:41.777729+00,GOOD,test,web,2026-06-24 14:41:41.777729+00

COPY schema_versions FROM STDIN WITH CSV HEADER;
version,description,applied_at
1,"Create core tables: events, anomalies, baselines, rule_feedback, indexes",2026-06-23 05:41:56.139468+00
2,Create ip_threat_profiles and active_learning_queue tables,2026-06-23 05:41:56.141109+00
3,Create/upgrade rule_baselines with consolidated schema,2026-06-23 05:41:56.157459+00
4,Create threshold tuning tables,2026-06-23 05:41:56.158512+00
5,Create concept drift events table,2026-06-23 05:41:56.159116+00
6,"Final cleanup: legacy constraints, missing columns, event log_type",2026-06-23 05:41:56.159933+00
7,Create signal_weight_tuning for adaptive threat signal weights,2026-06-23 05:41:56.165482+00

COPY signal_weight_tuning FROM STDIN WITH CSV HEADER;
signal_type,base_weight,learned_weight,attack_correlations,benign_correlations,total_detections,last_attack_feedback,last_benign_feedback,updated_at

COPY threshold_detection_records FROM STDIN WITH CSV HEADER;
id,anomaly_id,anomaly_type,score,threshold_type,timestamp,created_at

COPY threshold_feedback FROM STDIN WITH CSV HEADER;
id,anomaly_id,label,reason,user_id,created_at
1,1,false_positive,legitimate traffic spike during backup,test,2026-06-23 09:08:17.693353+00
2,1,false_positive,legitimate traffic spike during backup,test,2026-06-23 10:34:06.759484+00
3,1,false_positive,legitimate traffic spike during backup,test,2026-06-23 11:19:54.411158+00
4,1,false_positive,legitimate traffic spike during backup,test,2026-06-23 12:59:55.175927+00
5,1,false_positive,legitimate traffic spike during backup,test,2026-06-23 15:31:25.958139+00
6,1,false_positive,legitimate traffic spike during backup,test,2026-06-24 01:14:40.089472+00

COPY threshold_tuning_history FROM STDIN WITH CSV HEADER;
id,threshold_type,old_value,new_value,reason,created_at

