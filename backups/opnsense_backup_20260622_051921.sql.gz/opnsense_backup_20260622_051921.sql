--
-- PostgreSQL database dump
--

\restrict 38XGUhZTgUBz88tqQkGylRue5RMGCiRwnctbGIoSjnqCLCh5uvwFyArXr7ocQJ5

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.anomalies DROP CONSTRAINT IF EXISTS anomalies_event_id_fkey;
DROP INDEX IF EXISTS public.idx_threshold_tuning_type;
DROP INDEX IF EXISTS public.idx_threshold_tuning_history_type;
DROP INDEX IF EXISTS public.idx_threshold_tuning_history_created;
DROP INDEX IF EXISTS public.idx_threshold_tuning_created;
DROP INDEX IF EXISTS public.idx_threshold_feedback_label;
DROP INDEX IF EXISTS public.idx_threshold_feedback_created;
DROP INDEX IF EXISTS public.idx_threshold_feedback_anomaly;
DROP INDEX IF EXISTS public.idx_threshold_detection_type;
DROP INDEX IF EXISTS public.idx_threshold_detection_timestamp;
DROP INDEX IF EXISTS public.idx_threshold_detection_threshold_type;
DROP INDEX IF EXISTS public.idx_threshold_detection_anomaly;
DROP INDEX IF EXISTS public.idx_rule_temporal_patterns_rule_name;
DROP INDEX IF EXISTS public.idx_rule_feedback_timestamp;
DROP INDEX IF EXISTS public.idx_rule_feedback_rule_name;
DROP INDEX IF EXISTS public.idx_rule_feedback_label;
DROP INDEX IF EXISTS public.idx_rule_baselines_rule_name;
DROP INDEX IF EXISTS public.idx_rule_baselines_rule;
DROP INDEX IF EXISTS public.idx_rule_baselines_ip;
DROP INDEX IF EXISTS public.idx_ip_threat_profiles_score;
DROP INDEX IF EXISTS public.idx_events_timestamp;
DROP INDEX IF EXISTS public.idx_events_src_ip;
DROP INDEX IF EXISTS public.idx_events_rule_name;
DROP INDEX IF EXISTS public.idx_events_proto;
DROP INDEX IF EXISTS public.idx_events_interface;
DROP INDEX IF EXISTS public.idx_events_dst_port;
DROP INDEX IF EXISTS public.idx_events_dst_ip;
DROP INDEX IF EXISTS public.idx_events_action;
DROP INDEX IF EXISTS public.idx_drift_events_timestamp;
DROP INDEX IF EXISTS public.idx_drift_events_severity;
DROP INDEX IF EXISTS public.idx_drift_events_scope;
DROP INDEX IF EXISTS public.idx_drift_events_metric;
DROP INDEX IF EXISTS public.idx_baselines_metric_window;
DROP INDEX IF EXISTS public.idx_baselines_metric;
DROP INDEX IF EXISTS public.idx_anomalies_timestamp;
DROP INDEX IF EXISTS public.idx_anomalies_src_ip;
DROP INDEX IF EXISTS public.idx_anomalies_severity;
DROP INDEX IF EXISTS public.idx_anomalies_created_at;
DROP INDEX IF EXISTS public.idx_anomalies_attack_type;
DROP INDEX IF EXISTS public.idx_anomalies_alert_sent;
DROP INDEX IF EXISTS public.idx_active_learning_queue_status;
DROP INDEX IF EXISTS public.idx_active_learning_queue_rule;
DROP INDEX IF EXISTS public.idx_active_learning_queue_created;
ALTER TABLE IF EXISTS ONLY public.threshold_tuning_history DROP CONSTRAINT IF EXISTS threshold_tuning_history_pkey;
ALTER TABLE IF EXISTS ONLY public.threshold_feedback DROP CONSTRAINT IF EXISTS threshold_feedback_pkey;
ALTER TABLE IF EXISTS ONLY public.threshold_detection_records DROP CONSTRAINT IF EXISTS threshold_detection_records_pkey;
ALTER TABLE IF EXISTS ONLY public.rule_temporal_patterns DROP CONSTRAINT IF EXISTS rule_temporal_patterns_rule_name_key;
ALTER TABLE IF EXISTS ONLY public.rule_temporal_patterns DROP CONSTRAINT IF EXISTS rule_temporal_patterns_pkey;
ALTER TABLE IF EXISTS ONLY public.rule_feedback DROP CONSTRAINT IF EXISTS rule_feedback_pkey;
ALTER TABLE IF EXISTS ONLY public.rule_baselines DROP CONSTRAINT IF EXISTS rule_baselines_rule_name_key;
ALTER TABLE IF EXISTS ONLY public.rule_baselines DROP CONSTRAINT IF EXISTS rule_baselines_pkey;
ALTER TABLE IF EXISTS ONLY public.ip_threat_profiles DROP CONSTRAINT IF EXISTS ip_threat_profiles_pkey;
ALTER TABLE IF EXISTS ONLY public.ip_threat_profiles DROP CONSTRAINT IF EXISTS ip_threat_profiles_ip_key;
ALTER TABLE IF EXISTS ONLY public.events DROP CONSTRAINT IF EXISTS events_pkey;
ALTER TABLE IF EXISTS ONLY public.drift_events DROP CONSTRAINT IF EXISTS drift_events_pkey;
ALTER TABLE IF EXISTS ONLY public.baselines DROP CONSTRAINT IF EXISTS baselines_pkey;
ALTER TABLE IF EXISTS ONLY public.anomalies DROP CONSTRAINT IF EXISTS anomalies_pkey;
ALTER TABLE IF EXISTS ONLY public.active_learning_queue DROP CONSTRAINT IF EXISTS active_learning_queue_pkey;
ALTER TABLE IF EXISTS public.threshold_tuning_history ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.threshold_feedback ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.threshold_detection_records ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.rule_temporal_patterns ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.rule_feedback ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.rule_baselines ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.ip_threat_profiles ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.events ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.drift_events ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.baselines ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.anomalies ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.active_learning_queue ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.threshold_tuning_history_id_seq;
DROP TABLE IF EXISTS public.threshold_tuning_history;
DROP SEQUENCE IF EXISTS public.threshold_feedback_id_seq;
DROP TABLE IF EXISTS public.threshold_feedback;
DROP SEQUENCE IF EXISTS public.threshold_detection_records_id_seq;
DROP TABLE IF EXISTS public.threshold_detection_records;
DROP SEQUENCE IF EXISTS public.rule_temporal_patterns_id_seq;
DROP TABLE IF EXISTS public.rule_temporal_patterns;
DROP SEQUENCE IF EXISTS public.rule_feedback_id_seq;
DROP TABLE IF EXISTS public.rule_feedback;
DROP SEQUENCE IF EXISTS public.rule_baselines_id_seq;
DROP TABLE IF EXISTS public.rule_baselines;
DROP SEQUENCE IF EXISTS public.ip_threat_profiles_id_seq;
DROP TABLE IF EXISTS public.ip_threat_profiles;
DROP SEQUENCE IF EXISTS public.events_id_seq;
DROP TABLE IF EXISTS public.events;
DROP SEQUENCE IF EXISTS public.drift_events_id_seq;
DROP TABLE IF EXISTS public.drift_events;
DROP SEQUENCE IF EXISTS public.baselines_id_seq;
DROP TABLE IF EXISTS public.baselines;
DROP SEQUENCE IF EXISTS public.anomalies_id_seq;
DROP TABLE IF EXISTS public.anomalies;
DROP SEQUENCE IF EXISTS public.active_learning_queue_id_seq;
DROP TABLE IF EXISTS public.active_learning_queue;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: active_learning_queue; Type: TABLE; Schema: public; Owner: opnsense
--

CREATE TABLE public.active_learning_queue (
    id integer NOT NULL,
    rule_name text NOT NULL,
    rule_description text,
    classification text DEFAULT 'UNCERTAIN'::text NOT NULL,
    confidence double precision DEFAULT 0,
    reasons text,
    status text DEFAULT 'pending'::text NOT NULL,
    resolved_classification text,
    resolved_notes text,
    created_at timestamp with time zone DEFAULT now(),
    resolved_at timestamp with time zone
);


ALTER TABLE public.active_learning_queue OWNER TO opnsense;

--
-- Name: active_learning_queue_id_seq; Type: SEQUENCE; Schema: public; Owner: opnsense
--

CREATE SEQUENCE public.active_learning_queue_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.active_learning_queue_id_seq OWNER TO opnsense;

--
-- Name: active_learning_queue_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: opnsense
--

ALTER SEQUENCE public.active_learning_queue_id_seq OWNED BY public.active_learning_queue.id;


--
-- Name: anomalies; Type: TABLE; Schema: public; Owner: opnsense
--

CREATE TABLE public.anomalies (
    id integer NOT NULL,
    event_id integer,
    "timestamp" timestamp with time zone NOT NULL,
    attack_type text NOT NULL,
    severity text NOT NULL,
    src_ip text,
    dst_ip text,
    dst_port integer,
    proto text,
    description text,
    detail jsonb,
    alert_sent boolean DEFAULT false,
    discord_sent boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.anomalies OWNER TO opnsense;

--
-- Name: anomalies_id_seq; Type: SEQUENCE; Schema: public; Owner: opnsense
--

CREATE SEQUENCE public.anomalies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.anomalies_id_seq OWNER TO opnsense;

--
-- Name: anomalies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: opnsense
--

ALTER SEQUENCE public.anomalies_id_seq OWNED BY public.anomalies.id;


--
-- Name: baselines; Type: TABLE; Schema: public; Owner: opnsense
--

CREATE TABLE public.baselines (
    id integer NOT NULL,
    metric text NOT NULL,
    time_window timestamp with time zone NOT NULL,
    mean_value double precision NOT NULL,
    stddev double precision NOT NULL,
    sample_count integer NOT NULL,
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.baselines OWNER TO opnsense;

--
-- Name: baselines_id_seq; Type: SEQUENCE; Schema: public; Owner: opnsense
--

CREATE SEQUENCE public.baselines_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.baselines_id_seq OWNER TO opnsense;

--
-- Name: baselines_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: opnsense
--

ALTER SEQUENCE public.baselines_id_seq OWNED BY public.baselines.id;


--
-- Name: drift_events; Type: TABLE; Schema: public; Owner: opnsense
--

CREATE TABLE public.drift_events (
    id integer NOT NULL,
    metric text NOT NULL,
    scope text NOT NULL,
    old_mean double precision NOT NULL,
    new_mean double precision NOT NULL,
    drift_magnitude double precision NOT NULL,
    window_size integer NOT NULL,
    severity text NOT NULL,
    description text,
    triggered_retrain boolean DEFAULT false,
    "timestamp" timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.drift_events OWNER TO opnsense;

--
-- Name: drift_events_id_seq; Type: SEQUENCE; Schema: public; Owner: opnsense
--

CREATE SEQUENCE public.drift_events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.drift_events_id_seq OWNER TO opnsense;

--
-- Name: drift_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: opnsense
--

ALTER SEQUENCE public.drift_events_id_seq OWNED BY public.drift_events.id;


--
-- Name: events; Type: TABLE; Schema: public; Owner: opnsense
--

CREATE TABLE public.events (
    id integer NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    src_ip text,
    dst_ip text,
    src_hostname text,
    dst_hostname text,
    src_port integer,
    dst_port integer,
    proto text,
    action text,
    interface text,
    direction text,
    version integer,
    ip_ttl integer,
    ip_total_length integer,
    tcp_flags text,
    tcp_seq integer,
    tcp_ack integer,
    tcp_window integer,
    tcp_options text,
    udp_datalen integer,
    icmp_datalen integer,
    raw_message text,
    rule_name text,
    ingested_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.events OWNER TO opnsense;

--
-- Name: events_id_seq; Type: SEQUENCE; Schema: public; Owner: opnsense
--

CREATE SEQUENCE public.events_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.events_id_seq OWNER TO opnsense;

--
-- Name: events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: opnsense
--

ALTER SEQUENCE public.events_id_seq OWNED BY public.events.id;


--
-- Name: ip_threat_profiles; Type: TABLE; Schema: public; Owner: opnsense
--

CREATE TABLE public.ip_threat_profiles (
    id integer NOT NULL,
    ip text NOT NULL,
    unified_score double precision DEFAULT 0,
    total_events integer DEFAULT 0,
    firewall_events integer DEFAULT 0,
    http_events integer DEFAULT 0,
    ids_events integer DEFAULT 0,
    zenarmor_events integer DEFAULT 0,
    nginx_events integer DEFAULT 0,
    baseline_deviations jsonb DEFAULT '[]'::jsonb,
    geo_info jsonb,
    first_seen timestamp with time zone,
    last_seen timestamp with time zone
);


ALTER TABLE public.ip_threat_profiles OWNER TO opnsense;

--
-- Name: ip_threat_profiles_id_seq; Type: SEQUENCE; Schema: public; Owner: opnsense
--

CREATE SEQUENCE public.ip_threat_profiles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ip_threat_profiles_id_seq OWNER TO opnsense;

--
-- Name: ip_threat_profiles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: opnsense
--

ALTER SEQUENCE public.ip_threat_profiles_id_seq OWNED BY public.ip_threat_profiles.id;


--
-- Name: rule_baselines; Type: TABLE; Schema: public; Owner: opnsense
--

CREATE TABLE public.rule_baselines (
    id integer NOT NULL,
    rule_name text NOT NULL,
    avg_port_diversity double precision DEFAULT 0,
    avg_dest_diversity double precision DEFAULT 0,
    avg_volume double precision DEFAULT 0,
    avg_block_ratio double precision DEFAULT 0,
    baseline_goodness double precision DEFAULT 0,
    sample_count integer DEFAULT 0,
    baseline_updated boolean DEFAULT false,
    window_start timestamp with time zone,
    window_end timestamp with time zone,
    updated_at timestamp with time zone DEFAULT now(),
    ip text,
    hour integer,
    rule text
);


ALTER TABLE public.rule_baselines OWNER TO opnsense;

--
-- Name: rule_baselines_id_seq; Type: SEQUENCE; Schema: public; Owner: opnsense
--

CREATE SEQUENCE public.rule_baselines_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.rule_baselines_id_seq OWNER TO opnsense;

--
-- Name: rule_baselines_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: opnsense
--

ALTER SEQUENCE public.rule_baselines_id_seq OWNED BY public.rule_baselines.id;


--
-- Name: rule_feedback; Type: TABLE; Schema: public; Owner: opnsense
--

CREATE TABLE public.rule_feedback (
    id integer NOT NULL,
    rule_name text NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    label text NOT NULL,
    reason text,
    user_id text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.rule_feedback OWNER TO opnsense;

--
-- Name: rule_feedback_id_seq; Type: SEQUENCE; Schema: public; Owner: opnsense
--

CREATE SEQUENCE public.rule_feedback_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.rule_feedback_id_seq OWNER TO opnsense;

--
-- Name: rule_feedback_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: opnsense
--

ALTER SEQUENCE public.rule_feedback_id_seq OWNED BY public.rule_feedback.id;


--
-- Name: rule_temporal_patterns; Type: TABLE; Schema: public; Owner: opnsense
--

CREATE TABLE public.rule_temporal_patterns (
    id integer NOT NULL,
    rule_name text NOT NULL,
    hour_distribution jsonb DEFAULT '{}'::jsonb,
    total_samples integer DEFAULT 0,
    updated_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.rule_temporal_patterns OWNER TO opnsense;

--
-- Name: rule_temporal_patterns_id_seq; Type: SEQUENCE; Schema: public; Owner: opnsense
--

CREATE SEQUENCE public.rule_temporal_patterns_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.rule_temporal_patterns_id_seq OWNER TO opnsense;

--
-- Name: rule_temporal_patterns_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: opnsense
--

ALTER SEQUENCE public.rule_temporal_patterns_id_seq OWNED BY public.rule_temporal_patterns.id;


--
-- Name: threshold_detection_records; Type: TABLE; Schema: public; Owner: opnsense
--

CREATE TABLE public.threshold_detection_records (
    id integer NOT NULL,
    anomaly_id integer NOT NULL,
    anomaly_type text NOT NULL,
    score double precision NOT NULL,
    threshold_type text NOT NULL,
    "timestamp" timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.threshold_detection_records OWNER TO opnsense;

--
-- Name: threshold_detection_records_id_seq; Type: SEQUENCE; Schema: public; Owner: opnsense
--

CREATE SEQUENCE public.threshold_detection_records_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.threshold_detection_records_id_seq OWNER TO opnsense;

--
-- Name: threshold_detection_records_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: opnsense
--

ALTER SEQUENCE public.threshold_detection_records_id_seq OWNED BY public.threshold_detection_records.id;


--
-- Name: threshold_feedback; Type: TABLE; Schema: public; Owner: opnsense
--

CREATE TABLE public.threshold_feedback (
    id integer NOT NULL,
    anomaly_id integer NOT NULL,
    label text NOT NULL,
    reason text,
    user_id text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.threshold_feedback OWNER TO opnsense;

--
-- Name: threshold_feedback_id_seq; Type: SEQUENCE; Schema: public; Owner: opnsense
--

CREATE SEQUENCE public.threshold_feedback_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.threshold_feedback_id_seq OWNER TO opnsense;

--
-- Name: threshold_feedback_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: opnsense
--

ALTER SEQUENCE public.threshold_feedback_id_seq OWNED BY public.threshold_feedback.id;


--
-- Name: threshold_tuning_history; Type: TABLE; Schema: public; Owner: opnsense
--

CREATE TABLE public.threshold_tuning_history (
    id integer NOT NULL,
    threshold_type text NOT NULL,
    old_value double precision NOT NULL,
    new_value double precision NOT NULL,
    reason text,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.threshold_tuning_history OWNER TO opnsense;

--
-- Name: threshold_tuning_history_id_seq; Type: SEQUENCE; Schema: public; Owner: opnsense
--

CREATE SEQUENCE public.threshold_tuning_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.threshold_tuning_history_id_seq OWNER TO opnsense;

--
-- Name: threshold_tuning_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: opnsense
--

ALTER SEQUENCE public.threshold_tuning_history_id_seq OWNED BY public.threshold_tuning_history.id;


--
-- Name: active_learning_queue id; Type: DEFAULT; Schema: public; Owner: opnsense
--

ALTER TABLE ONLY public.active_learning_queue ALTER COLUMN id SET DEFAULT nextval('public.active_learning_queue_id_seq'::regclass);


--
-- Name: anomalies id; Type: DEFAULT; Schema: public; Owner: opnsense
--

ALTER TABLE ONLY public.anomalies ALTER COLUMN id SET DEFAULT nextval('public.anomalies_id_seq'::regclass);


--
-- Name: baselines id; Type: DEFAULT; Schema: public; Owner: opnsense
--

ALTER TABLE ONLY public.baselines ALTER COLUMN id SET DEFAULT nextval('public.baselines_id_seq'::regclass);


--
-- Name: drift_events id; Type: DEFAULT; Schema: public; Owner: opnsense
--

ALTER TABLE ONLY public.drift_events ALTER COLUMN id SET DEFAULT nextval('public.drift_events_id_seq'::regclass);


--
-- Name: events id; Type: DEFAULT; Schema: public; Owner: opnsense
--

ALTER TABLE ONLY public.events ALTER COLUMN id SET DEFAULT nextval('public.events_id_seq'::regclass);


--
-- Name: ip_threat_profiles id; Type: DEFAULT; Schema: public; Owner: opnsense
--

ALTER TABLE ONLY public.ip_threat_profiles ALTER COLUMN id SET DEFAULT nextval('public.ip_threat_profiles_id_seq'::regclass);


--
-- Name: rule_baselines id; Type: DEFAULT; Schema: public; Owner: opnsense
--

ALTER TABLE ONLY public.rule_baselines ALTER COLUMN id SET DEFAULT nextval('public.rule_baselines_id_seq'::regclass);


--
-- Name: rule_feedback id; Type: DEFAULT; Schema: public; Owner: opnsense
--

ALTER TABLE ONLY public.rule_feedback ALTER COLUMN id SET DEFAULT nextval('public.rule_feedback_id_seq'::regclass);


--
-- Name: rule_temporal_patterns id; Type: DEFAULT; Schema: public; Owner: opnsense
--

ALTER TABLE ONLY public.rule_temporal_patterns ALTER COLUMN id SET DEFAULT nextval('public.rule_temporal_patterns_id_seq'::regclass);


--
-- Name: threshold_detection_records id; Type: DEFAULT; Schema: public; Owner: opnsense
--

ALTER TABLE ONLY public.threshold_detection_records ALTER COLUMN id SET DEFAULT nextval('public.threshold_detection_records_id_seq'::regclass);


--
-- Name: threshold_feedback id; Type: DEFAULT; Schema: public; Owner: opnsense
--

ALTER TABLE ONLY public.threshold_feedback ALTER COLUMN id SET DEFAULT nextval('public.threshold_feedback_id_seq'::regclass);


--
-- Name: threshold_tuning_history id; Type: DEFAULT; Schema: public; Owner: opnsense
--

ALTER TABLE ONLY public.threshold_tuning_history ALTER COLUMN id SET DEFAULT nextval('public.threshold_tuning_history_id_seq'::regclass);


--
-- Data for Name: active_learning_queue; Type: TABLE DATA; Schema: public; Owner: opnsense
--

COPY public.active_learning_queue (id, rule_name, rule_description, classification, confidence, reasons, status, resolved_classification, resolved_notes, created_at, resolved_at) FROM stdin;
\.


--
-- Data for Name: anomalies; Type: TABLE DATA; Schema: public; Owner: opnsense
--

COPY public.anomalies (id, event_id, "timestamp", attack_type, severity, src_ip, dst_ip, dst_port, proto, description, detail, alert_sent, discord_sent, created_at) FROM stdin;
\.


--
-- Data for Name: baselines; Type: TABLE DATA; Schema: public; Owner: opnsense
--

COPY public.baselines (id, metric, time_window, mean_value, stddev, sample_count, updated_at) FROM stdin;
\.


--
-- Data for Name: drift_events; Type: TABLE DATA; Schema: public; Owner: opnsense
--

COPY public.drift_events (id, metric, scope, old_mean, new_mean, drift_magnitude, window_size, severity, description, triggered_retrain, "timestamp", created_at) FROM stdin;
\.


--
-- Data for Name: events; Type: TABLE DATA; Schema: public; Owner: opnsense
--

COPY public.events (id, "timestamp", src_ip, dst_ip, src_hostname, dst_hostname, src_port, dst_port, proto, action, interface, direction, version, ip_ttl, ip_total_length, tcp_flags, tcp_seq, tcp_ack, tcp_window, tcp_options, udp_datalen, icmp_datalen, raw_message, rule_name, ingested_at) FROM stdin;
\.


--
-- Data for Name: ip_threat_profiles; Type: TABLE DATA; Schema: public; Owner: opnsense
--

COPY public.ip_threat_profiles (id, ip, unified_score, total_events, firewall_events, http_events, ids_events, zenarmor_events, nginx_events, baseline_deviations, geo_info, first_seen, last_seen) FROM stdin;
\.


--
-- Data for Name: rule_baselines; Type: TABLE DATA; Schema: public; Owner: opnsense
--

COPY public.rule_baselines (id, rule_name, avg_port_diversity, avg_dest_diversity, avg_volume, avg_block_ratio, baseline_goodness, sample_count, baseline_updated, window_start, window_end, updated_at, ip, hour, rule) FROM stdin;
\.


--
-- Data for Name: rule_feedback; Type: TABLE DATA; Schema: public; Owner: opnsense
--

COPY public.rule_feedback (id, rule_name, "timestamp", label, reason, user_id, created_at) FROM stdin;
\.


--
-- Data for Name: rule_temporal_patterns; Type: TABLE DATA; Schema: public; Owner: opnsense
--

COPY public.rule_temporal_patterns (id, rule_name, hour_distribution, total_samples, updated_at) FROM stdin;
\.


--
-- Data for Name: threshold_detection_records; Type: TABLE DATA; Schema: public; Owner: opnsense
--

COPY public.threshold_detection_records (id, anomaly_id, anomaly_type, score, threshold_type, "timestamp", created_at) FROM stdin;
\.


--
-- Data for Name: threshold_feedback; Type: TABLE DATA; Schema: public; Owner: opnsense
--

COPY public.threshold_feedback (id, anomaly_id, label, reason, user_id, created_at) FROM stdin;
\.


--
-- Data for Name: threshold_tuning_history; Type: TABLE DATA; Schema: public; Owner: opnsense
--

COPY public.threshold_tuning_history (id, threshold_type, old_value, new_value, reason, created_at) FROM stdin;
\.


--
-- Name: active_learning_queue_id_seq; Type: SEQUENCE SET; Schema: public; Owner: opnsense
--

SELECT pg_catalog.setval('public.active_learning_queue_id_seq', 1, false);


--
-- Name: anomalies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: opnsense
--

SELECT pg_catalog.setval('public.anomalies_id_seq', 1, false);


--
-- Name: baselines_id_seq; Type: SEQUENCE SET; Schema: public; Owner: opnsense
--

SELECT pg_catalog.setval('public.baselines_id_seq', 1, false);


--
-- Name: drift_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: opnsense
--

SELECT pg_catalog.setval('public.drift_events_id_seq', 1, false);


--
-- Name: events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: opnsense
--

SELECT pg_catalog.setval('public.events_id_seq', 1, false);


--
-- Name: ip_threat_profiles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: opnsense
--

SELECT pg_catalog.setval('public.ip_threat_profiles_id_seq', 1, false);


--
-- Name: rule_baselines_id_seq; Type: SEQUENCE SET; Schema: public; Owner: opnsense
--

SELECT pg_catalog.setval('public.rule_baselines_id_seq', 1, false);


--
-- Name: rule_feedback_id_seq; Type: SEQUENCE SET; Schema: public; Owner: opnsense
--

SELECT pg_catalog.setval('public.rule_feedback_id_seq', 1, false);


--
-- Name: rule_temporal_patterns_id_seq; Type: SEQUENCE SET; Schema: public; Owner: opnsense
--

SELECT pg_catalog.setval('public.rule_temporal_patterns_id_seq', 1, false);


--
-- Name: threshold_detection_records_id_seq; Type: SEQUENCE SET; Schema: public; Owner: opnsense
--

SELECT pg_catalog.setval('public.threshold_detection_records_id_seq', 1, false);


--
-- Name: threshold_feedback_id_seq; Type: SEQUENCE SET; Schema: public; Owner: opnsense
--

SELECT pg_catalog.setval('public.threshold_feedback_id_seq', 1, false);


--
-- Name: threshold_tuning_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: opnsense
--

SELECT pg_catalog.setval('public.threshold_tuning_history_id_seq', 1, false);


--
-- Name: active_learning_queue active_learning_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: opnsense
--

ALTER TABLE ONLY public.active_learning_queue
    ADD CONSTRAINT active_learning_queue_pkey PRIMARY KEY (id);


--
-- Name: anomalies anomalies_pkey; Type: CONSTRAINT; Schema: public; Owner: opnsense
--

ALTER TABLE ONLY public.anomalies
    ADD CONSTRAINT anomalies_pkey PRIMARY KEY (id);


--
-- Name: baselines baselines_pkey; Type: CONSTRAINT; Schema: public; Owner: opnsense
--

ALTER TABLE ONLY public.baselines
    ADD CONSTRAINT baselines_pkey PRIMARY KEY (id);


--
-- Name: drift_events drift_events_pkey; Type: CONSTRAINT; Schema: public; Owner: opnsense
--

ALTER TABLE ONLY public.drift_events
    ADD CONSTRAINT drift_events_pkey PRIMARY KEY (id);


--
-- Name: events events_pkey; Type: CONSTRAINT; Schema: public; Owner: opnsense
--

ALTER TABLE ONLY public.events
    ADD CONSTRAINT events_pkey PRIMARY KEY (id);


--
-- Name: ip_threat_profiles ip_threat_profiles_ip_key; Type: CONSTRAINT; Schema: public; Owner: opnsense
--

ALTER TABLE ONLY public.ip_threat_profiles
    ADD CONSTRAINT ip_threat_profiles_ip_key UNIQUE (ip);


--
-- Name: ip_threat_profiles ip_threat_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: opnsense
--

ALTER TABLE ONLY public.ip_threat_profiles
    ADD CONSTRAINT ip_threat_profiles_pkey PRIMARY KEY (id);


--
-- Name: rule_baselines rule_baselines_pkey; Type: CONSTRAINT; Schema: public; Owner: opnsense
--

ALTER TABLE ONLY public.rule_baselines
    ADD CONSTRAINT rule_baselines_pkey PRIMARY KEY (id);


--
-- Name: rule_baselines rule_baselines_rule_name_key; Type: CONSTRAINT; Schema: public; Owner: opnsense
--

ALTER TABLE ONLY public.rule_baselines
    ADD CONSTRAINT rule_baselines_rule_name_key UNIQUE (rule_name);


--
-- Name: rule_feedback rule_feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: opnsense
--

ALTER TABLE ONLY public.rule_feedback
    ADD CONSTRAINT rule_feedback_pkey PRIMARY KEY (id);


--
-- Name: rule_temporal_patterns rule_temporal_patterns_pkey; Type: CONSTRAINT; Schema: public; Owner: opnsense
--

ALTER TABLE ONLY public.rule_temporal_patterns
    ADD CONSTRAINT rule_temporal_patterns_pkey PRIMARY KEY (id);


--
-- Name: rule_temporal_patterns rule_temporal_patterns_rule_name_key; Type: CONSTRAINT; Schema: public; Owner: opnsense
--

ALTER TABLE ONLY public.rule_temporal_patterns
    ADD CONSTRAINT rule_temporal_patterns_rule_name_key UNIQUE (rule_name);


--
-- Name: threshold_detection_records threshold_detection_records_pkey; Type: CONSTRAINT; Schema: public; Owner: opnsense
--

ALTER TABLE ONLY public.threshold_detection_records
    ADD CONSTRAINT threshold_detection_records_pkey PRIMARY KEY (id);


--
-- Name: threshold_feedback threshold_feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: opnsense
--

ALTER TABLE ONLY public.threshold_feedback
    ADD CONSTRAINT threshold_feedback_pkey PRIMARY KEY (id);


--
-- Name: threshold_tuning_history threshold_tuning_history_pkey; Type: CONSTRAINT; Schema: public; Owner: opnsense
--

ALTER TABLE ONLY public.threshold_tuning_history
    ADD CONSTRAINT threshold_tuning_history_pkey PRIMARY KEY (id);


--
-- Name: idx_active_learning_queue_created; Type: INDEX; Schema: public; Owner: opnsense
--

CREATE INDEX idx_active_learning_queue_created ON public.active_learning_queue USING btree (created_at);


--
-- Name: idx_active_learning_queue_rule; Type: INDEX; Schema: public; Owner: opnsense
--

CREATE INDEX idx_active_learning_queue_rule ON public.active_learning_queue USING btree (rule_name);


--
-- Name: idx_active_learning_queue_status; Type: INDEX; Schema: public; Owner: opnsense
--

CREATE INDEX idx_active_learning_queue_status ON public.active_learning_queue USING btree (status);


--
-- Name: idx_anomalies_alert_sent; Type: INDEX; Schema: public; Owner: opnsense
--

CREATE INDEX idx_anomalies_alert_sent ON public.anomalies USING btree (alert_sent);


--
-- Name: idx_anomalies_attack_type; Type: INDEX; Schema: public; Owner: opnsense
--

CREATE INDEX idx_anomalies_attack_type ON public.anomalies USING btree (attack_type);


--
-- Name: idx_anomalies_created_at; Type: INDEX; Schema: public; Owner: opnsense
--

CREATE INDEX idx_anomalies_created_at ON public.anomalies USING btree (created_at);


--
-- Name: idx_anomalies_severity; Type: INDEX; Schema: public; Owner: opnsense
--

CREATE INDEX idx_anomalies_severity ON public.anomalies USING btree (severity);


--
-- Name: idx_anomalies_src_ip; Type: INDEX; Schema: public; Owner: opnsense
--

CREATE INDEX idx_anomalies_src_ip ON public.anomalies USING btree (src_ip) WHERE (src_ip IS NOT NULL);


--
-- Name: idx_anomalies_timestamp; Type: INDEX; Schema: public; Owner: opnsense
--

CREATE INDEX idx_anomalies_timestamp ON public.anomalies USING btree ("timestamp");


--
-- Name: idx_baselines_metric; Type: INDEX; Schema: public; Owner: opnsense
--

CREATE INDEX idx_baselines_metric ON public.baselines USING btree (metric, time_window);


--
-- Name: idx_baselines_metric_window; Type: INDEX; Schema: public; Owner: opnsense
--

CREATE UNIQUE INDEX idx_baselines_metric_window ON public.baselines USING btree (metric, time_window);


--
-- Name: idx_drift_events_metric; Type: INDEX; Schema: public; Owner: opnsense
--

CREATE INDEX idx_drift_events_metric ON public.drift_events USING btree (metric);


--
-- Name: idx_drift_events_scope; Type: INDEX; Schema: public; Owner: opnsense
--

CREATE INDEX idx_drift_events_scope ON public.drift_events USING btree (scope);


--
-- Name: idx_drift_events_severity; Type: INDEX; Schema: public; Owner: opnsense
--

CREATE INDEX idx_drift_events_severity ON public.drift_events USING btree (severity);


--
-- Name: idx_drift_events_timestamp; Type: INDEX; Schema: public; Owner: opnsense
--

CREATE INDEX idx_drift_events_timestamp ON public.drift_events USING btree ("timestamp");


--
-- Name: idx_events_action; Type: INDEX; Schema: public; Owner: opnsense
--

CREATE INDEX idx_events_action ON public.events USING btree (action);


--
-- Name: idx_events_dst_ip; Type: INDEX; Schema: public; Owner: opnsense
--

CREATE INDEX idx_events_dst_ip ON public.events USING btree (dst_ip) WHERE (dst_ip IS NOT NULL);


--
-- Name: idx_events_dst_port; Type: INDEX; Schema: public; Owner: opnsense
--

CREATE INDEX idx_events_dst_port ON public.events USING btree (dst_port) WHERE (dst_port IS NOT NULL);


--
-- Name: idx_events_interface; Type: INDEX; Schema: public; Owner: opnsense
--

CREATE INDEX idx_events_interface ON public.events USING btree (interface);


--
-- Name: idx_events_proto; Type: INDEX; Schema: public; Owner: opnsense
--

CREATE INDEX idx_events_proto ON public.events USING btree (proto);


--
-- Name: idx_events_rule_name; Type: INDEX; Schema: public; Owner: opnsense
--

CREATE INDEX idx_events_rule_name ON public.events USING btree (rule_name) WHERE (rule_name IS NOT NULL);


--
-- Name: idx_events_src_ip; Type: INDEX; Schema: public; Owner: opnsense
--

CREATE INDEX idx_events_src_ip ON public.events USING btree (src_ip) WHERE (src_ip IS NOT NULL);


--
-- Name: idx_events_timestamp; Type: INDEX; Schema: public; Owner: opnsense
--

CREATE INDEX idx_events_timestamp ON public.events USING btree ("timestamp");


--
-- Name: idx_ip_threat_profiles_score; Type: INDEX; Schema: public; Owner: opnsense
--

CREATE INDEX idx_ip_threat_profiles_score ON public.ip_threat_profiles USING btree (unified_score DESC);


--
-- Name: idx_rule_baselines_ip; Type: INDEX; Schema: public; Owner: opnsense
--

CREATE INDEX idx_rule_baselines_ip ON public.rule_baselines USING btree (ip) WHERE (ip IS NOT NULL);


--
-- Name: idx_rule_baselines_rule; Type: INDEX; Schema: public; Owner: opnsense
--

CREATE INDEX idx_rule_baselines_rule ON public.rule_baselines USING btree (rule);


--
-- Name: idx_rule_baselines_rule_name; Type: INDEX; Schema: public; Owner: opnsense
--

CREATE UNIQUE INDEX idx_rule_baselines_rule_name ON public.rule_baselines USING btree (rule_name) WHERE ((ip IS NULL) AND (hour IS NULL));


--
-- Name: idx_rule_feedback_label; Type: INDEX; Schema: public; Owner: opnsense
--

CREATE INDEX idx_rule_feedback_label ON public.rule_feedback USING btree (label);


--
-- Name: idx_rule_feedback_rule_name; Type: INDEX; Schema: public; Owner: opnsense
--

CREATE INDEX idx_rule_feedback_rule_name ON public.rule_feedback USING btree (rule_name);


--
-- Name: idx_rule_feedback_timestamp; Type: INDEX; Schema: public; Owner: opnsense
--

CREATE INDEX idx_rule_feedback_timestamp ON public.rule_feedback USING btree ("timestamp");


--
-- Name: idx_rule_temporal_patterns_rule_name; Type: INDEX; Schema: public; Owner: opnsense
--

CREATE INDEX idx_rule_temporal_patterns_rule_name ON public.rule_temporal_patterns USING btree (rule_name);


--
-- Name: idx_threshold_detection_anomaly; Type: INDEX; Schema: public; Owner: opnsense
--

CREATE INDEX idx_threshold_detection_anomaly ON public.threshold_detection_records USING btree (anomaly_id);


--
-- Name: idx_threshold_detection_threshold_type; Type: INDEX; Schema: public; Owner: opnsense
--

CREATE INDEX idx_threshold_detection_threshold_type ON public.threshold_detection_records USING btree (threshold_type);


--
-- Name: idx_threshold_detection_timestamp; Type: INDEX; Schema: public; Owner: opnsense
--

CREATE INDEX idx_threshold_detection_timestamp ON public.threshold_detection_records USING btree ("timestamp");


--
-- Name: idx_threshold_detection_type; Type: INDEX; Schema: public; Owner: opnsense
--

CREATE INDEX idx_threshold_detection_type ON public.threshold_detection_records USING btree (anomaly_type);


--
-- Name: idx_threshold_feedback_anomaly; Type: INDEX; Schema: public; Owner: opnsense
--

CREATE INDEX idx_threshold_feedback_anomaly ON public.threshold_feedback USING btree (anomaly_id);


--
-- Name: idx_threshold_feedback_created; Type: INDEX; Schema: public; Owner: opnsense
--

CREATE INDEX idx_threshold_feedback_created ON public.threshold_feedback USING btree (created_at);


--
-- Name: idx_threshold_feedback_label; Type: INDEX; Schema: public; Owner: opnsense
--

CREATE INDEX idx_threshold_feedback_label ON public.threshold_feedback USING btree (label);


--
-- Name: idx_threshold_tuning_created; Type: INDEX; Schema: public; Owner: opnsense
--

CREATE INDEX idx_threshold_tuning_created ON public.threshold_tuning_history USING btree (created_at);


--
-- Name: idx_threshold_tuning_history_created; Type: INDEX; Schema: public; Owner: opnsense
--

CREATE INDEX idx_threshold_tuning_history_created ON public.threshold_tuning_history USING btree (created_at);


--
-- Name: idx_threshold_tuning_history_type; Type: INDEX; Schema: public; Owner: opnsense
--

CREATE INDEX idx_threshold_tuning_history_type ON public.threshold_tuning_history USING btree (threshold_type);


--
-- Name: idx_threshold_tuning_type; Type: INDEX; Schema: public; Owner: opnsense
--

CREATE INDEX idx_threshold_tuning_type ON public.threshold_tuning_history USING btree (threshold_type);


--
-- Name: anomalies anomalies_event_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: opnsense
--

ALTER TABLE ONLY public.anomalies
    ADD CONSTRAINT anomalies_event_id_fkey FOREIGN KEY (event_id) REFERENCES public.events(id);


--
-- PostgreSQL database dump complete
--

\unrestrict 38XGUhZTgUBz88tqQkGylRue5RMGCiRwnctbGIoSjnqCLCh5uvwFyArXr7ocQJ5
